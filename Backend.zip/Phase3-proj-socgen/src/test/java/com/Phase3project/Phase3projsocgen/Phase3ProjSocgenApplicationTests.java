package com.Phase3project.Phase3projsocgen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3ProjSocgenApplicationTests {

	@Test
	void contextLoads() {
	}

}
