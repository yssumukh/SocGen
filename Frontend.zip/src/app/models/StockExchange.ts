export interface StockExchange {
  id?: number;
  name?: string;
}
