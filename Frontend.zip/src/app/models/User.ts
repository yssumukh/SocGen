export interface User {
  name?: string;
  password?: string;
  email?: string;
  admin?:boolean
  role?: string;
}
